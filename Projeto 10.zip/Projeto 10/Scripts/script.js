//window.alert("Você ganhou um premio");
//window.confirm("Gostaria de receber seu premio");
window.prompt("Insira seu nome");
